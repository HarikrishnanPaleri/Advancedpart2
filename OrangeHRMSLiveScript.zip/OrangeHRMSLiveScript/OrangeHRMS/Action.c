Action()
{

	/* Login */

	web_add_auto_header("Accept-Language", 
		"en-GB,en;q=0.5");

	web_submit_data("validate",
		"Action=https://opensource-demo.orangehrmlive.com/web/index.php/auth/validate",
		"Method=POST",
		"RecContentType=text/html",
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/auth/login",
		"Snapshot=t4.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=_token", "Value={_token}", ENDITEM,
		"Name=username", "Value={User}", ENDITEM,
		"Name=password", "Value={Pass}", ENDITEM,
		LAST);

	web_url("action-summary", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/employees/action-summary", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_url("leaves", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/employees/leaves?date=2024-02-28", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_url("feed", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/buzz/feed?limit=5&offset=0&sortOrder=DESC&sortField=share.createdAtUtc", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("push", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/events/push", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("shortcuts", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/shortcuts", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_url("locations", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/employees/locations", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_url("subunit", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/employees/subunit", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	/* Pending Self Review */

	lr_think_time(33);

	web_url("myPerformanceReview", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/performance/myPerformanceReview", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_url("reviews", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/performance/reviews?limit=50&offset=0&sortField=performanceReview.statusId&sortOrder=ASC", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/performance/myPerformanceReview", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	/* Employee Tracker */

	lr_think_time(21);

	web_url("viewEmployeePerformanceTrackerList", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/performance/viewEmployeePerformanceTrackerList", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/performance/myPerformanceReview", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_url("trackers", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/performance/employees/trackers?limit=50&offset=0&sortField=tracker.modifiedDate&sortOrder=DESC&includeEmployees=onlyCurrent", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/performance/viewEmployeePerformanceTrackerList", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	/* Directory */

	lr_think_time(26);

	web_url("viewDirectory", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/directory/viewDirectory", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/performance/viewEmployeePerformanceTrackerList", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_url("employees", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/directory/employees?limit=14&offset=0", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/directory/viewDirectory", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}
